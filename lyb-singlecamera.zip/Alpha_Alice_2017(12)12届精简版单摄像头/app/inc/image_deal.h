#ifndef _IMAGE_DEAL_H
#define _IMAGE_DEAL_H

//extern uint8 flag0=0,flag1=0;


extern uint8 pixel[128];
extern uint8 imgbuff[CAMERA_SIZE];//����洢����ͼ�������
extern uint8 imgbuff2[CAMERA_H][CAMERA_W];//ӥ������ͷ��ѹ���ݺ󱣴�λ��
extern int16 car_dif,per_car_dif;
extern uint8 Left;
extern uint8 Right;

extern uint8 left[64],right[64];

extern uint8 mid_line; 

extern uint8 stopFlag;
extern int8 mid[64];
extern int hope;
extern int Fit_Wide[CAMERA_H+5];
extern int i,j;
extern uint8 road_type;
extern int quanzhi[];
extern uint8 mid_line_far;
extern int quanzhi_far[];
extern int16 car_dif_far;
extern uint8 imgbuff2_eye[CAMERA_H][CAMERA_W];

extern uint8 imgbuff_eye[CAMERA_SIZE];


void line_island();
void Find_line();
void island();

void find_line();
void find_rline();

void ova_find_line();
void judgeStop();

void botton_cross();
void jude_cross();
void line_adjust (int st,int ed,int8 *array,int small,int big) ;

void piancha();


void testCircle();
void  jude_round();

void getFlag(uint8 flag);

void test();

#endif

