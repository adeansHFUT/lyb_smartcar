#ifndef _ISR_H_
#define _ISR_H_
#define KEY_MAX 4

extern uint8 count,Time_flag_10ms,Time_flag_20ms, Time_flag_30ms,
      Time_flag_40ms,Time_flag_50ms,Time_flag_5s;

void PIT0_IRQHandler(void);

void PIT1_IRQHandler(void);

void PIT2_IRQHandler(void);

void PIT3_IRQHandler(void);

uint8 key_value();

uint8 key_init();

#endif