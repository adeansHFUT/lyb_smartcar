#ifndef _PID_H
#define _PID_H

struct LineValue
{
    uint8 left;
    uint8 right;
    int16 car_position;
    uint8 mid;
    int16 mid_line; 
    int16 car_dif;  
    int16 miss_line;
    int16 per_miss_line;
    int16 per1_miss_line;
    
};


/******2016�����������ӳ���******/
void line_init();
void find_line();
void line_deal();
/*******************************/

#endif
