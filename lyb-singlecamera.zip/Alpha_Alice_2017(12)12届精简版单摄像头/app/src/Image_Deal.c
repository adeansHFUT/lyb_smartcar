#include "include.h"
#include "include.h"
#include "isr.h"




/****************************************����Ϊ����ͷͼ��������****************************************/

uint8 pixel[];
uint8 imgbuff[CAMERA_SIZE];//����洢����ͼ�������
uint8 imgbuff_eye[CAMERA_SIZE];//�ڶ�������ͷ����

uint8 imgbuff2[CAMERA_H][CAMERA_W];//ӥ������ͷ��ѹ���ݺ󱣴�λ��
uint8 imgbuff2_eye[CAMERA_H][CAMERA_W];//2ӥ������ͷ��ѹ���ݺ󱣴�λ��

uint8 car_position=39;//����
//int Fit_Wide[CAMERA_H+5]={0,0,0,0,0,0,0,0,0,2,4,5,5,6,6,6,7,7,7,8,8,10,10,11,11,11,12,12,13,13,13,13,13,14,14,16,16,16,16,17,18,18,18,19,19,19,20,20,20,20,23};
//int Fit_Wide[CAMERA_H+5]={0,0,0,0,0,4,5,6,7,7,8,9,9,10,10,11,11,12,12,13,14,14,15,15,16,16,16,16,17,17,18,18,19,19,19,20,20,21,21,22,23,23,23,24,25,25,25,26,26,27,27,28,28,29,29,30,30,31,32};
int Fit_Wide[CAMERA_H+5]={0,0,0,0,0,6,10,10,12,12,14,16,16,16,20,20,20,20,22,22,24,26,26,26,26,28,30,30,28,30,30,32,32,34,17,18,19,19,19,20,20,21,21,21,21,22,22,23,23,24,24,25,25,26,26,27,27,27,28,28};
int i=0,j=0;
//uint8 mid=18;
uint8 Left;
uint8 Right;

uint8 left[64];
uint8 right[64];
//for find line
uint8 mid_line=39;
//for speed control
uint8 mid_line_far=39;

//for find line
int16 car_dif=0; 
int16 per_car_dif=0;
//for speed control
int16 car_dif_far=0;



//����ͷ��Ȩ
int8 mid[64];
int hope;//��Чǰհ
//add for judge stop
uint8 stopFlag=0;
//add for judge out of circle
uint8 road_type=1;//������������0��԰��

uint8 flag0=0,flag1=0,flag2=0,flag3=0,flag4=0;
//Ȩֵ
int quanzhi[60]={
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
3, 3, 3, 3, 3, 3, 3 ,3, 3, 3,
4, 4, 4, 4, 4, 4, 4, 4, 4, 4,
5, 5, 5, 7, 7, 7, 7, 7, 7,7,
10, 10, 10, 10, 10, 10, 10, 10, 10, 10,
10, 10, 10, 10, 10, 5, 5, 5, 5, 5};

int quanzhi_circle[60]={
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
1, 1, 1, 1, 1, 1, 1 ,1, 1, 1,
1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
7, 7, 7, 7, 7, 5, 5, 5, 5, 5,
10, 10, 10, 10, 10, 10, 10, 10, 10, 10,
10, 10, 10, 10, 10, 5, 5, 5, 5, 5};

int quanzhi_far[60]={
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 10, 10 ,10, 10, 10,
10, 10, 10, 10, 10, 10, 10, 10, 10, 10,
4, 4, 4, 4, 4, 4, 4, 3, 2,1,
1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0};


void Find_line()
{
  hope=10;       //ʵ����Чǰհ
  
  //��ֹ��59�е���Ϊ��
  mid[51]=mid[52]=mid[53]=41;
  //left[31]=10;
  //right[31]=70;
  for(i=50;i>0;i--)
  {
    if(imgbuff2[i][mid[i+1]]==0)
      break;
    
    for(j=mid[i+1];j>0;j--)			    
      if(imgbuff2[i][j]==0)             
           break;                    //����Ǻڵ㣬��ó���ֵ
    left[i]=j;
        
    for(j=mid[i+1];j<80;j++)			    
      if(imgbuff2[i][j]==0)                    
        break;
    right[i]=j;                      //����Ǻڵ㣬��ó���ֵ
     mid[i]=(left[i]+right[i]+1)/2;
        

  }
  hope=i+1; 
  island();
  if(road_type==0)
    line_island();
  
  
  
    
}

void island()//����ʶ��
{
  uint8 i=30,j,x=30;
  while(i--)
  {
    if(imgbuff2[23][i]!=imgbuff2[23][i+1])
      flag0++;
  }
    if(flag0==2)
    {
      for(j=25;j>10;j--)
        if(right[j]>right[j+1])
          break;
      if(j==10)
        flag1=1;
    }
  if(flag1==1)
  {
    
    for(;x>15;x--)
    {
      if(left[x]!=0)
        break;
    }
    if(x==15)
      flag2=1;
    
  }

  if(flag2)
  {
    x=30;
    
    while(--x)
      if(imgbuff2[23][x]!=imgbuff2[23][x+1])
        break;
    if(x>=2)
    {
      x=x-2;
      uint8 a=23;
      while(a--)
        if(imgbuff2[a][x]!=imgbuff2[a-1][x])
          break;
      uint8 b=23;
      while(b++)
        if(imgbuff2[b][x]!=imgbuff2[b+1][x])
          break;
      
      if((a-b)<10)
      {
        flag3=1;
      }
      
    }
    if(flag3)
    {
      uint8 x1=50,x2=50;
      for(;x1>20;x1--)
      {
        if(left[x1]!=0)
          break;
      }
      
      for(;x2>20;x2--)
      {
        if(left[x2]!=0)
          break;
      }
      if(x2==20&&x1==20)
      {
        road_type=0;
        flag1=0;
        flag2=0;
        flag3=0;
      }
    }
    /*if(left[16]>left[15]&&left[15]>=left[14]&&left[16]>left[17]&&left[17]>=left[18])
    {
      
        road_type=0;
        flag1=0;
        flag2=0;
      
    }*/
  }
  flag0=0;
  
}

void line_island()
{
  hope=10;       //ʵ����Чǰհ
  //uint8 flag4=0;
  //��ֹ��59�е���Ϊ��
  mid[31]=mid[32]=mid[33]=41;
  
  for(i=30;i>0;i--)
  {
    if(imgbuff2[i][mid[i+1]]==0)
      break;
    for(j=mid[i+1];j>0;j--)			    
      if(imgbuff2[i][j]==0)             
           break;                    //����Ǻڵ㣬��ó���ֵ
    left[i]=j;

     for(j=mid[i+1];j<80;j++)			    
      if(imgbuff2[i][j]==0)                    
        break;
    right[i]=j;                      //����Ǻڵ㣬��ó���ֵ
        
   mid[i]=(Fit_Wide[i]+left[i]+1);
    
   
  }
  if(right[20]<right[19]&&right[19]<=right[18]&&right[20]<right[21]&&right[21]<=right[22])
     flag4=1;
  

  if(flag4)
  {
    uint8 d=30,d2=30;
    while(imgbuff2[d--][0]==2);
    while(imgbuff2[d2--][79]==2);
    d=d+1;
    if(d<=20&&d2>=10)
    {
      if(left[d-1]-left[d]>=10||left[d-2]-left[d-1]>=10||left[d-3]-left[d-2]>=10)
      {
        uint8 j;
        j=d2;
        for(;j>=10;j--)
        {
          if(right[j]>right[j+1])
            break;
        }
        if(j==10)
        //if(right[d2]>=right[d2-1]&&right[d2-1]>=right[d2-2]&&right[d2-2]>=right[d2-3]&&((d2-d3>15)||d3<10))
        {
          flag4=0;
          road_type=1;
        }
      }
    }
  }
  hope=i+1; 
}

void find_line()//Ѳ��
{

  hope=15;       //ʵ����Чǰհ
  
                       
  
  //Բ�ж�
  //circle_in();
  
  for(i=59;i>0;i--)
  {
    if(imgbuff2[i][mid[i+1]]==0&&i<55)
      break;
    
    for(j=mid[i+1];j>0;j--)			    
      if(imgbuff2[i][j]==0)             
           break;                    //����Ǻڵ㣬��ó���ֵ
    left[i]=j;
        
    for(j=mid[i+1];j<80;j++)			    
      if(imgbuff2[i][j]==0)                    
        break;
    right[i]=j;                      //����Ǻڵ㣬��ó���ֵ
        
                                
     //�ײ�ʮ���ж� 
    if((left[59]+left[58]+left[57]+left[56]==0||right[59]+right[58]+right[57]+right[56]==320)&&i==56)
    {
      if(left[59]+left[58]+left[57]+left[56]==0&&right[59]+right[58]+right[57]+right[56]==320)
         botton_cross();
      else if(left[59]+left[58]+left[57]+left[56]==0&&right[56]==80)
      {
        if(imgbuff2[55][79]==2&&imgbuff2[54][79]==2&&imgbuff2[53][79]==2)
          botton_cross();
      }
      else if(right[59]+right[58]+right[57]+right[56]==320&&left[56]==0)
      {
        if(imgbuff2[55][0]==2&&imgbuff2[54][0]==2&&imgbuff2[53][0]==2)
          botton_cross();
      }
    }

    if(i<55)
    {
      if(left[i]==0&&right[i]==80)
      {
        mid[i]=2*mid[i+1]-mid[i+2];
        jude_cross();       //�ж�ʮ��
      }
      else if(left[i]==0)
      {
        mid[i]=mid[i+1]+right[i]-right[i+1];          
        jude_cross();
       
      }
      else if(right[i]==80)
      {
        mid[i]=mid[i+1]+left[i]-left[i+1];
          jude_cross();
      }
      else
      {
        mid[i]=(left[i]+right[i]+1)/2;
        if(road_type==1)
        {  
          jude_round();   //�ж�Բ
          
        }
        if(road_type==0)
          break;
      }
    }
    else
    {
      if(left[i]==0&&right[i]==80)
        mid[i]=42;
      else if(left[i]==0)
        mid[i]=(right[i]-Fit_Wide[i])<(right[i]/2)?(right[i]-Fit_Wide[i]):(right[i]/2);
      else if(right[i]==80)
        mid[i]=(left[i]+Fit_Wide[i])>((right[i]+80)/2)?(right[i]+Fit_Wide[i]):((left[i]+80)/2);
      else
        mid[i]=(left[i]+right[i]+1)/2;
    }
    
    if(right[i]<5||left[i]>75||mid[i]<2||mid[i]>78)
          break;
  
    imgbuff2[i][mid[i]]=0;         
  }
  
  hope=i+1;             //��Чǰհ

  }

    
void piancha()//Ѳ������ֵƫ��
{

  per_car_dif=car_dif;
  uint8 i,st=30,ed=10;
  int16 sum_up=0,sum_down=0;//sum_up_far,sum_down_far;
  int sum_up_far=0,sum_down_far=0;
  if(hope>ed)
    ed=hope;
  for(i=st;i>ed;i--)
  {
    /*if(mid[i]<=5&&i>35)
    {car_dif=24;return;}
    if(mid[i]>=75&&i>35)
    {car_dif=-24;return;}*/
    
    if(road_type==1)
    {
      sum_up+=(int16)(mid[i])*quanzhi[i];  //��Ȩ
      sum_down+=quanzhi[i];
    }
    else
    {
      sum_up+=(int16)(mid[i])*quanzhi_circle[i];  //��Ȩ
      sum_down+=quanzhi_circle[i];
    }
    /*sum_up_far+=(mid[i])*quanzhi_far[i];
    sum_down_far+=quanzhi_far[i];*/
  }
 
    mid_line=sum_up/sum_down;
    mid_line_far=sum_up_far/sum_down_far;

  car_dif=car_position-mid_line;
  car_dif_far=abs(car_position-mid_line_far);
   
}

void botton_cross() //�ײ�ʮ��
{
  uint8 i0=59,i1=59,i2=59,min,mid0;
  while(imgbuff2[i0--][30]==2);
  while(imgbuff2[i1--][40]==2);
  while(imgbuff2[i2--][50]==2);
  min=i0<i1?i0:i1;
  min=min<i2?min:i2;

  if(min==i0)
        mid0=30;
  else if(min==i1)
        mid0=40;
  else if(min==i2)
        mid0=50;
  
  for(i=59;i>0;i--)
  {
    for(j=mid0;j>0;j--)
      if(imgbuff2[i][j]==0)             
           break;                    //����Ǻڵ㣬��ó���ֵ
    left[i]=j;
        
    for(j=mid0;j<=79;j++)			    
      if(imgbuff2[i][j]==0)                    
        break;
    right[i]=j;
    
    mid[i]=(left[i]+right[i])/2;
    mid[59]=39;
      if(i<min+10)
    if((right[i]-left[i]<2.2*Fit_Wide[i])&&(right[i+1]-left[i+1]<2.2*Fit_Wide[i+1])&&(right[i+2]-left[i+2]<2.2*Fit_Wide[i+2]))
    {
       line_adjust (59,i+2,mid,i+2,58);
       break;
    }
                                                                                                                        
  }
    
}

//����б�ʲ���                                                                                          
void line_adjust (int st,int ed,int8 *array,int small,int big) 
{
	float k=(array[ed]-array[st])*1.0/(ed-st);
	for(int i=small;i<=big;i++)
		array[i]=array[small]+(uint8)(k*(i-small)+0.5);
        
}
                                                                                                                        
void jude_cross()      //�ж�ʮ��
{      
  if(left[i]==0&&right[i]>right[i+1]&&right[i+1]>right[i+2])//&&i<=55)
  {
    int j0;
    if(i+3>59)
      j0=right[59];
    else
      j0=right[i+3];
    int i0=i;
    i0=i0-1;
    while(imgbuff2[i0][j0]==2)
    {
      i0--;
    }
    
    if(i0<5)
	return ;
    i0=i0-2;
    right[i0]=79;
    left[i0]=0;
    for(;j0>0;j0--)
    {
      if(imgbuff2[i0][j0+1]==0&&imgbuff2[i0][j0]==2)
        right[i0]=j0;
      if(imgbuff2[i0][j0+1]==2&&imgbuff2[i0][j0]==0)
        {left[i0]=j0;break;}
    }
    if(left[i0]!=0&&right[i0]!=79)
      mid[i0]=(left[i0]+right[i0])/2;
    else
      mid[i0]=right[i0]-Fit_Wide[i0];
    
    line_adjust(59,i0,mid,i0,i+5);
    i=i0;
  }
  else if(right[i]==80&&left[i]<left[i+1]&&left[i+1]<left[i+2])//&&i<=55)
  {
    
    int j0;
    if(i+3>59)
      j0=left[59];
    else
      j0=left[i+3];
    int i0=i;
    

    
    while(imgbuff2[i0--][j0]==2);
    if(i0<5)
	return ;
    i0=i0-2;
    right[i0]=79;
    left[i0]=0;
    for(;j0<80;j0++)
    {
      if(imgbuff2[i0][j0-1]==0&&imgbuff2[i0][j0]==2)
        left[i0]=j0;
      if(imgbuff2[i0][j0-1]==2&&imgbuff2[i0][j0]==0)
        {right[i0]=j0;break;}
    }
    if(left[i0]!=0&&right[i0]!=79)
      mid[i0]=(left[i0]+right[i0])/2;
    else
      mid[i0]=left[i0]+Fit_Wide[i0];
    
    line_adjust(59,i0,mid,i0,i+5);
     i=i0;
  }
  
  
  else if(left[i]==0&&right[i]==80&&i<=55)
  {
    int j0;
    if(i+3>59)
      j0=left[59];
    else
      j0=left[i+3];
    int i0=i;
    while(imgbuff2[i0--][j0]==2);
    if(i0<5)
	return ;
    i0=i0-2;
    right[i0]=79;
    left[i0]=0;
    for(;j0<80;j0++)
    {
      if(imgbuff2[i0][j0-1]==0&&imgbuff2[i0][j0]==2)
        left[i0]=j0;
      if(imgbuff2[i0][j0-1]==2&&imgbuff2[i0][j0]==0)
      {right[i0]=j0;break;}
    }
    if(left[i0]!=0&&right[i0]!=79)
      mid[i0]=(left[i0]+right[i0])/2;
    else
      mid[i0]=left[i0]+Fit_Wide[i0];
    
    line_adjust(59,i0,mid,i0,i+5);
      i=i0;
 
  }
     
    
   
}
                                        
void  jude_round()//�ж�Բ
{
  if(left[i]<left[i+1]&&right[i]>right[i+1]&&i>20)
  {
     if(left[i+1]<left[i+2]&&right[i+1]>right[i+2])
     {  
       int i0=i;
       while((right[i0]-left[i0])>(right[i0+1]-left[i0+1])&&i0<50)
         i0++;
       if(i0>=50)
         return;
       int j0=mid[i0],left_flag=0,right_flag=0;
       while(imgbuff2[i0--][j0]==2);
         
       if(imgbuff2[i0-2][j0]==0)
       {
        i0=i0-2;
        int j1;
        for(j1=j0;j1>0;j1--)
          if(imgbuff2[i0][j1]==2)
          {
            left_flag=1;
            break;
          }
        for(j1=j0;j1<80;j1++)
          if(imgbuff2[i0][j1]==2)
          {
            right_flag=1;
            break;
          }
        if(right_flag&&left_flag)
        {
          road_type=0;
          
        }
       
       }
     }

  }
}

void find_rline()//��Բ��Ѳ��
{
  int i,j;
  static int flag=0,flag2=0,flag3=0,flag4=0;
  mid[60]=40;
  mid[61]=40;
    if(imgbuff2[59][40]==2)
    mid[60]=40;
  else if(imgbuff2[59][30]==2)
    mid[60]=30;
  else if(imgbuff2[59][50]==2)
    mid[60]=50;
  else if(imgbuff2[59][20]==2)
    mid[60]=20;
  else if(imgbuff2[59][60]==2)
    mid[60]=60;
  else if(imgbuff2[59][10]==2)
    mid[60]=10;
  else if(imgbuff2[59][70]==2)
    mid[60]=70;     
  
  for(i=59;i>0;i--)
  {
    for(j=mid[i+1];j<80;j++)
    {
      if(imgbuff2[i][j]==2&&imgbuff2[i][j+1]==0)
        break;
    }
    right[i]=j;
    if(right[i]==80)
      mid[i]=2*mid[i+1]-mid[i+2];
    else
      mid[i]=right[i]-Fit_Wide[i];
    if(mid[i]<4)
      mid[i]=4;
    for(j=mid[i];j>0;j--)
    {
      if(imgbuff2[i][j]==0&&imgbuff2[i][j+1]==2)
        break;
    }
    left[i]=j;
    
    if(mid[i]>75||mid[i]<0)
      break;
    if(mid[i]==0&&i<45)
      break;
    
    imgbuff2[i][mid[i]]=0;
  }
  hope=i;
  
  
  if((right[57]!=80&&right[58]!=80&&right[56]!=80)&&(left[58]<3&&left[57]<3&&left[56]<3))
     flag=1;
                                                                  
  if(flag==1&&left[59]>1&&left[58]>1&&left[57]>1&&right[58]<77&&right[57]<77)
    flag3=1;
  if(flag2==1)
    
  {
        int max=59;
        for(i=59;i>40;i--)
        {
          if(left[max]<left[i])
            max=i;
        }
        if(max>50&&left[max]>left[59]&&left[max]>left[40]+3)
        {
          flag3=1;

        }
  }
  if(flag3==1)
  {
    if(left[59]==0&&left[58]==0&&right[58]<77&&right[59]<77)
    {
      flag4=1;
    }
  }
  
  if(flag4==1)
  {
    if(left[59]>2&&left[58]>2&&right[58]<77&&right[59]<77)//��Բ��
    {
        road_type=1;
        //car_position=52;
        flag=0;
        flag2=0;
        flag3=0;
        flag4=0;
        
        
    }
  }
   //printf("road_type:%d\t  flag:%d  flag2:%d\t  flag3=%d  flag4=%d\n",road_type,flag,flag2,flag3,flag4);

 //  printf("stopFlag:%d \t Alpha:%d \t road_type:%d \t flag3=%d \t CH=%d\n ",stopFlag,Alpha,road_type,flag3,CH);

  
 


                                                                  
}


void test()
{
  printf("road_type:%d\t   flag1:%d  flag2:%d   flag3:%d   flag4:%d    car_dif:%d\n ",road_type,flag1,flag2,flag3,flag4,car_dif);

  //printf("Left:%d \t Right:%d \t car_dif:%d\n ",Left,Right,car_dif);
 
  
}




void OV_Image_Deal()
{
    camera_get_img();//��ȡ����ѹ
    img_extract(imgbuff2,imgbuff,CAMERA_SIZE);//imgbuff2=80*60  
   // judge_circle();    
    //ova_find_line();//Զ��Ϊ0 ����59 ��ɫΪ0 ��ɫ2
}        
    


void testCircle()
{
 
  printf("%d--%d--%d\n",left,right,mid_line);
}


void judgeStop()
{
  uint8 i,j;
  uint8 count=0;
  static int num=0;
  num++;
  i=55;
  
  
  for(j=0;j<79;j++)
  {
    if(imgbuff2[i][j]-imgbuff2[i][j+1])
    {
      count++;
    }
  }
  if(count>10&&num>=500)
  {
      stopFlag=1;
      num=500;
  }
  
}    

void getFlag(uint8 flag)
{
  stopFlag=flag;
}


