
#include "include.h"


int16 Right_val,Left_val;
uint16 straightVal=320;
uint16 tempVal3=220;
uint16 tempVal2=160;
uint16 tempVal1=140;
uint16 circleVal=100;

int16 shit[2];

void speed_gather()  //�ٶȻ�ȡ
{
  if(Time_flag_10ms)
  {
    Time_flag_10ms=0;
    /*���������ݵĲɼ�*/
    Right_val = ftm_quad_get (FTM2);//��ȡFTM���������������
    shit[0]=Right_val;
    ftm_quad_clean (FTM2);          //��FTM���������������
    
    Left_val = lptmr_pulse_get();   //��ȡlptmr�ļ���ֵ
    shit[1]=Left_val;
    lptmr_pulse_clean();            //���lptmr����  
  }
}

/*ɽ����λ��������ʾ����*/
void shiboqi()
{
  int size=sizeof(shit),i=0;
  uart_putchar(UART4,0x03);
  uart_putchar(UART4,0xfc);

   for(i=0;i<size;i++)
     uart_putchar(UART4,*((uint8 *)(shit)+i)); 
              
  uart_putchar(UART4,0xfc);
  uart_putchar(UART4,0x03); 
}

void testSpeed()
{
  printf("%d---%d\n",Right_val,Left_val);
}
//copy from yu haitao
void speedPIDR(uint16 TarR,uint16 ActR )
{
      static int16 Last_ErrR=0,SumR=0;
      float Kp=5,Ki=0.3,Kd=8;
      int16 ErrR=(TarR-ActR)/2,pwmr,pwm0r;
      pwm0r=TarR+75;      
      pwmr=pwm0r+Kp*ErrR+Kd*(ErrR-Last_ErrR)+Ki*SumR;     
      
      Last_ErrR=ErrR;
      
      
      SumR+=ErrR;
      
      
      if(SumR>400)
          SumR=400;
      else if(SumR<-400)
          SumR=-400;


      if(pwmr>450)
          pwmr=450;
      else if(pwmr<-450)
          pwmr=-450;  

      
     
      if(pwmr>=0)
      {
          ftm_pwm_duty(FTM0,FTM_CH3,pwmr);          
          ftm_pwm_duty(FTM0,FTM_CH5,0);        
          
      }
      else
      {
          ftm_pwm_duty(FTM0,FTM_CH3,0);         
          ftm_pwm_duty(FTM0,FTM_CH5,-pwmr);          
      }  
    //  printf("pwmr:%d\n",pwmr);
  
}

void speedPIDL(uint16 TarL,uint16 ActL )
{
      static int16 Last_ErrL=0,SumL=0;
      float Kp=5,Ki=0.3,Kd=8;
      int16 ErrL=(TarL-ActL)/2,pwml,pwm0l;
      
      pwm0l=TarL+75;
    
      pwml=pwm0l+Kp*ErrL+Kd*(ErrL-Last_ErrL)+Ki*SumL;
      
      
      Last_ErrL=ErrL;
      SumL+=ErrL;
    
      if(SumL>400)
          SumL=400;
      else if(SumL<-400)
          SumL=-400;
      



      if(pwml>450)
          pwml=450;
      else if(pwml<-450)
          pwml=-450;
      

      
      
      if(pwml>=0)
      {
          ftm_pwm_duty(FTM0,FTM_CH2,pwml);          
          ftm_pwm_duty(FTM0,FTM_CH0,0);        
          
      }
      else
      {
          ftm_pwm_duty(FTM0,FTM_CH2,0);         
          ftm_pwm_duty(FTM0,FTM_CH0,-pwml);          
      }        
      
    //  printf("pwml:%d\n",pwml);
     
      
  
}

void speedControl()
{
  //TODO �ж��������
  
    if(abs(car_dif)<=3)
    {
        speedPIDR(straightVal,Left_val);
        speedPIDL(straightVal,Right_val);
        car_dif=0;
    }
  
      else if(abs(car_dif)>3&&abs(car_dif)<=10)    //&&wandao_flag==0) ,abs��ȡ����ֵ
      {
        speedPIDR((uint16)(tempVal3-8*car_dif),Left_val);
        speedPIDL((uint16)(tempVal3-8*car_dif),Right_val);
        
      }
      else if(abs(car_dif)>10&&abs(car_dif)<20)
      {
        speedPIDR((uint16)(tempVal2+2*car_dif),Left_val);
        speedPIDL((uint16)(tempVal2-2*car_dif),Right_val);
      }
               
      else
      {
        speedPIDR((uint16)(tempVal1+3*car_dif),Left_val);
        speedPIDL((uint16)(tempVal1-3*car_dif),Right_val);
      }
    
}
 
 
      
  
 /* if(stopFlag==0)
  {
    if(road_type==1&&hope<10&&abs(car_dif)<=3)
    {
        speedPIDR(straightVal,Left_val);
        speedPIDL(straightVal,Right_val);
        car_dif=0;
    }
  
    else if(road_type==1)
    {
  
      if(abs(car_dif)<=2)    //&&wandao_flag==0)
      {
        speedPIDR(straightVal-20*car_dif,Left_val);
        speedPIDL(straightVal-20*car_dif,Right_val);
        
        
      }
      else if(abs(car_dif)>5&&abs(car_dif)<=10)    //&&wandao_flag==0)
      {
        speedPIDR((uint16)(tempVal3-8*car_dif),Left_val);
        speedPIDL((uint16)(tempVal3-8*car_dif),Right_val);
        
      }
      else if(abs(car_dif)>10&&abs(car_dif)<20)
      {
        speedPIDR((uint16)(tempVal2+2*car_dif),Left_val);
        speedPIDL((uint16)(tempVal2-2*car_dif),Right_val);
      }
               
      else
      {
        speedPIDR((uint16)(tempVal1+3*car_dif),Left_val);
        speedPIDL((uint16)(tempVal1-3*car_dif),Right_val);
      }
    }
 
    
    else 
    {
        speedPIDR((uint16)(circleVal),Left_val);
        speedPIDL((uint16)(circleVal),Right_val);
    }
      
  }
  
  else
  {
    if(Left_val>40)
    {
      speedPIDR(40,Left_val);
    }
    else {ftm_pwm_init(FTM0, FTM_CH3, 10000, 0);}
    if(Right_val>40)
    {
      speedPIDL(40,Right_val);
    }
    else 
    {
      ftm_pwm_init(FTM0, FTM_CH3, 10000, 0);
    }
  }
*/
  

//�����λ���ε����ٶ� 
// ���� 001 ���� 000
void speedAdjust()
{
  uint8 key=key_value();
  
  if(key&0x01)
  {
    straightVal=200;
    tempVal3=180;
    tempVal2=160;
    tempVal1=140;
    circleVal=100;
   
    return ;
  }
  else
  {
     straightVal=320;
     tempVal3=220;
     tempVal2=160;
     tempVal1=140;
     circleVal=100;
  }
  return ;
}